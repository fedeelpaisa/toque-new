import { OperationsApp } from "@/components/operations-app";

export default function DashboardPage() {
  return <OperationsApp initialView="dashboard" />;
}
